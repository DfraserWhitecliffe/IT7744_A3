import { test, expect } from '@playwright/test';

test('Create, Edit, Delete post', async ({ page }) => {
    // Going to the login page
    await page.goto('http://localhost:8000/login');

    // Filling out the form for logging in
    await page.fill('input[name="username"]', 'admin');
    await page.fill('input[name="password"]', 'admin');
    await page.click('button:has-text("Login")');

    // Test gets auto moved to the dashboard

    // Filling out the form to make a post
    await page.fill('input[name="title"]', 'Playwright Post');
    await page.fill('textarea[name="body"]', 'This is a body');
    await page.setInputFiles('input[name="image"]', 'tests/fixtures/Playwright-Test.jpg');
    await page.click('button:has-text("Post")');
    await expect(page.locator('text=Post Succesfully Created')).toBeVisible({timeout: 80000 });

    // Updating the post
    await page.click('a:has-text("Update")');
    await page.fill('input[name="title"]', 'Updated Post');
    await page.click('button:has-text("Update")');
    await expect(page.locator('text=Post Succesfully Updated')).toBeVisible();

    // Deleting the post
    await page.locator('form:has(button:has-text("Delete"))').nth(0).evaluate(form=> form.submit());
    // Added a timeout here, since the test seems to be inconsistant without it. 
    await expect(page.locator('text=Post Succesfully Deleted')).toBeVisible({ timeout: 10000 });
});

test('Create new account and edit it', async ({ page }) => {
    // Going to the register page
    await page.goto('http://localhost:8000/register');
    
    // Filling it in
    await page.fill('input[name="username"]', 'Tailwind');
    await page.fill('input[name="email"]', 'test@tailwind.com');
    await page.fill('input[name="password"]', 'password');
    await page.fill('input[name="password_confirmation"]', 'password');
    await page.click('button:has-text("Register")');

    // Going to edit profile
    await page.goto('http://localhost:8000/profile');

    // Editing profile
    await page.fill('input[name="username"]', 'Playwright');
    await page.click('button:has-text("Update Profile")');
});

test('Admin Editing a user', async ({ page }) => {
    // Going to login
    await page.goto('http://localhost:8000/login');

    // Logging in as admin
    await page.fill('input[name="username"]', 'admin');
    await page.fill('input[name="password"]', 'admin');
    await page.click('button:has-text("Login")');
    
    // Going to admin/users
    await page.click('a:has-text("Admin Panel")');
    await page.click('a:has-text("Manage Users")');

    // Editing the Playwright account
    await page.getByRole('row').filter({ hasText: 'Playwright' }).getByText('Edit').click();
    await page.fill('input[name="username"]', 'Playwright-Edited');
    await page.click('button:has-text("Save")');
    await expect(page.locator('text=User updated! ')).toBeVisible();


});