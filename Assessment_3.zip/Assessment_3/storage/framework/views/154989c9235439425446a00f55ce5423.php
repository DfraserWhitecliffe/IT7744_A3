<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['post', 'full'=>false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['post', 'full'=>false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

        <div class="card">
            <h2 class='font-bold text-xl text-center mb-4'><?php echo e($post->title); ?></h2>
            <div class="h-52 rounded-md mb-4 w-full object-cover overflow-hidden">
                <?php if($post->image): ?>
                    <img src="<?php echo e(asset('storage/' .$post->image)); ?>" alt="" />
                <?php else: ?>
                    <img src="<?php echo e(asset('storage/post_images/default.jpg')); ?>" alt="" />
                <?php endif; ?>
                
            </div>
            
            <?php if($full): ?>
                <div class="text-sm">
                    <span><?php echo e($post->body); ?></span>
                </div>
                
            <?php else: ?>
                <div class="text-sm">
                    <span><?php echo e(Str::words($post->body, 15)); ?></span>
                    <a href="<?php echo e(route('posts.show', $post)); ?>" class="text-blue-500 text-xs">Read more &rarr;</a>
                </div>
                
            <?php endif; ?>
            <!--Moved this to the bottom of the card for readability and to match other apps-->
            <div class="text-xs mt-6">
                <span>Posted <?php echo e($post->created_at->diffForHumans()); ?> by</span>
                <a href='<?php echo e(route('posts.user',$post->user)); ?>' class="text-blue-500 font-medium"><?php echo e($post->user->username); ?></a>
            </div>
            
            <div class="flex items-center justify-end gap-4 mt-6">
                <?php echo e($slot); ?>

            </div>
            

        </div>  

    <?php /**PATH C:\xampp\htdocs\Assessment_3\resources\views/components/postCard.blade.php ENDPATH**/ ?>