<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <a href="<?php echo e(route('admin.users.index')); ?>" class="block mb-12 text-xs text-blue-500">
    &larr; Go back to your dashboard</a>
    <div class="max-w-md mx-auto bg-white p-6 rounded-lg shadow border border-gray-300">
        <h1 class="text-2xl font-bold mb-6 border-b pb-2">Edit User</h1>
        <form method="POST" action="<?php echo e(route('admin.users.update', $user)); ?>"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-5">
                <label for="username" class="block mb-1 font-semibold text-gray-700">Username</label>
                <input type="text" id="username" name="username" value="<?php echo e(old('username', $user->username)); ?>"
                class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400">
            </div>
            <div class="mb-5">
                <label for="email" class="block mb-1 font-semibold text-gray-700">Email</label>
                <input type="email" id="email" name="email" value="<?php echo e(old('email', $user->email)); ?>"
                class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400">
            </div>
            <div class="mb-6">
                <label for="role" class="block mb-1 font-semibold text-gray-700">Role</label>
                <select id="role" name="role"
                    class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400">
                    <option value="user" <?php if($user->role =='user'): echo 'selected'; endif; ?>>User</option>
                    <option value="admin" <?php if($user->role =='admin'): echo 'selected'; endif; ?>>Admin</option>
                </select>
            </div>
            <div class="mb-5">
                <label for="avatar" class="block mb-1 font-semibold text-gray-700">Avatar</label>
                <input type="file" name="avatar" class="w-full border border-gray-300 rounded px-3 py-2">
                <?php if($user->avatar): ?>
                    <div class="mt-2">
                        <img src="<?php echo e(asset('storage/' . $user->avatar)); ?>" alt="Avatar" class="h-16 rounded-full">
                    </div>
                <?php endif; ?>
            </div>
            <button type="submit" class="bg-[#56e2ca] text-white font-semibold px-6 py-2 rounded hover:bg-[#5eead4] transition">
            Save
            </button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\Assessment_3\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>