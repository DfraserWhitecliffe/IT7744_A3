<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(env('APP_NAME')); ?></title>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-[#faf5ff] text-slate-900">
    <header class="bg-[#6d28d9] shadow-lg">
        <nav>
            <div>
                <a href="<?php echo e(route('posts.index')); ?>" class="nav-link">Home</a>
                <?php if(auth()->guard()->check()): ?>
                    <!--Added moved this part here so the buttons are always on the screen for the user to see
                        Also had to add the ? here to make sure the program doesnt crash when the user is logged out-->
                    <?php if(auth()->user()?->role === 'admin'): ?>
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link ml-4">Admin Panel</a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="nav-link ml-4">Dashboard</a>
                <?php endif; ?>
            </div>
                
            <?php if(auth()->guard()->guest()): ?>
                <div class="flex items-center gap-4">
                    <a href="<?php echo e(route('login')); ?>" class="nav-link">Login</a>
                    <a href="<?php echo e(route('register')); ?>" class="nav-link">Register</a>
                </div>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>


                <div class="relative grid place-items-center" x-data="{open:false}">
                    <button class="round-btn" type="button" @click="open = !open">
                            <img src="<?php echo e(asset('img/avatar2.png')); ?>" alt="profile">
                    </button>

                    <!--Used translate here to move the dropdown to be under the user's profile-->
                    <div x-show="open" @click.outside="open=false"class="bg-white shadow-lg absolute 
                    top-10 right-0 rounded-lg overflow-hidden font-light min-w-[180px] translate-x-20">
                        <p class="px-4 py-2 text-sm text-gray-700 border-b text-center font-semibold">
                            <?php echo e(auth()->user()->username); ?></p>

                        <a href="<?php echo e(route('profile.edit')); ?>" class="block hover:bg-slate-100 px-4 py-2">Edit Profile</a>

                        <form action="<?php echo e(route('logout')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <!--Changed this to have a pointer-->
                            <button class="block w-full text-left hover:bg-slate-100 pl-4 pr-4 py-2 px-4 cursor-pointer">Logout</button>
                        </form>
                    </div>

                    
                </div>
            <?php endif; ?>
            
        </nav>
    </header>

    <main class="py-8 px-4 mx-auto max-w-screen-lg">
        <?php echo e($slot); ?>

    </main>

</body>
</html><?php /**PATH C:\xampp\htdocs\Assessment_3\resources\views/components/layout.blade.php ENDPATH**/ ?>