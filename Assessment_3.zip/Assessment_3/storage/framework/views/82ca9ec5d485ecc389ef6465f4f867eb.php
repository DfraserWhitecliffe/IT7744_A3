<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1 class="title text-center">Edit Profile</h1>
    <div class="mx-auto max-w-screen-sm card">
        <?php if(session('success')): ?>
            <?php if (isset($component)) { $__componentOriginalc115b9ff12b76915cc22a6040e27d5b7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc115b9ff12b76915cc22a6040e27d5b7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flashMsg','data' => ['msg' => ''.e(session('success')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flashMsg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['msg' => ''.e(session('success')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc115b9ff12b76915cc22a6040e27d5b7)): ?>
<?php $attributes = $__attributesOriginalc115b9ff12b76915cc22a6040e27d5b7; ?>
<?php unset($__attributesOriginalc115b9ff12b76915cc22a6040e27d5b7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc115b9ff12b76915cc22a6040e27d5b7)): ?>
<?php $component = $__componentOriginalc115b9ff12b76915cc22a6040e27d5b7; ?>
<?php unset($__componentOriginalc115b9ff12b76915cc22a6040e27d5b7); ?>
<?php endif; ?>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label for="username">Username</label>
                <input type="text" name="username" value="<?php echo e(old('username', $user->username)); ?>" class="input">
            </div>
            <div class="mb-4">
                <label for="email">Email</label>
                <input type="text" name="email" value="<?php echo e(old('email', $user->email)); ?>" class="input">
            </div>
            <div class="mb-4">
                <label for="password">New Password</label>
                <input type="password" name="password" class="input">
            </div>
            <div class="mb-4">
                <label for="password_confirmation">Confirm Password</label>
                <input type="password" name="password_confirmation" class="input">
            </div>
            <div class="mb-6">
                <label for="avatar">Profile Image</label>
                <input type="file" name="avatar" class="input">
                <?php if($user->avatar): ?>
                    <img src="<?php echo e(asset('storage/' . $user->avatar)); ?>" class="w-16 h-16 rounded-full mt-2">
                <?php endif; ?>
            </div>
            <button class="btn">Update Profile</button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Assessment_3\resources\views/auth/edit-profile.blade.php ENDPATH**/ ?>