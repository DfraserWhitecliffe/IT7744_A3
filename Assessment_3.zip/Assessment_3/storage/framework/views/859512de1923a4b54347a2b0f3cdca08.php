<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1 class="text-4xl font-extrabold mb-8 text-center text-slate-900 tracking-tight">
        Admin Dashboard
    </h1>
    <div class="space-y-6 max-w-md mx-auto text-center">
        <a href="<?php echo e(route('admin.users.index')); ?>"
            class="block p-5 bg-[#56e2ca] text-white rounded-lg shadow-md border
                border-[#56e2ca]
                hover:bg-[#3dbfaa] hover:shadow-lg transition duration-300
                font-semibold text-lg">
            Manage Users
        </a>
        <a href="<?php echo e(route('admin.posts.index')); ?>"
            class="block p-5 bg-[#56e2ca] text-white rounded-lg shadow-md border
                border-[#56e2ca]
                hover:bg-[#3dbfaa] hover:shadow-lg transition duration-300
                font-semibold text-lg">
            Manage Posts
        </a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Assessment_3\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>