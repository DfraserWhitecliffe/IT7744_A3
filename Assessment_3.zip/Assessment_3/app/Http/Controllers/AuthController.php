<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function register(Request $request) {
        $fields = $request->validate([
            'username' => ['required', 'max:50'],
            'email' => ['required', 'max:50', 'email', 'unique:users'],
            'password' => ['required', 'min:3', 'confirmed']
        ]);

        $user = User::create($fields);

        Auth::login($user);

        return redirect()-> route('dashboard');
    }

    public function login(Request $request){
        $fields = $request->validate([
            'username' => ['required', 'max:50'],
            'password' => ['required', 'min:3']
        ]);

        if (Auth::attempt($fields, $request->remember)) {
            return redirect()-> intended('dashboard');
        } else {
            return back()->withErrors([
                'failed' => 'Wrong username or password'
            ]);
        }
    }

    public function logout(Request $request){
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/');
    }
}
