<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
// use Illuminate\Routing\Controllers\HasMiddleware;
// use Illuminate\Routing\Controllers\Middleware;


class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    
    public function __construct()
    {
        $this->middleware('auth')->except(['index', 'show']);
    }

    public function index()
    {
        $posts = Post::latest()->paginate(6);
        return view('posts.index', ['posts'=>$posts]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $fields = $request ->validate([
            'title' =>['required', 'max:255'],
            'body' =>['required'],
            'image' =>['nullable', 'file', 'max:5000', 'mimes:png,jpg,webp']
        ]);

        $path = null;
        if($request->hasFile('image')){
            $path = Storage::disk('public')->put('post_images', $request->image);
        }

        Auth::user()->posts()->create([
            'title'=> $request->title,
            'body'=> $request->body,
            'image'=> $path,
        ]);
        return back()->with('success', 'Post Succesfully Created');
    }

    /**
     * Display the specified resource.
     */
    public function show(Post $post)
    {
        return view('posts.show', ['post'=>$post]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Post $post)
    {
        Gate::authorize('modify', $post);
        return view('posts.edit', ['post'=>$post]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Post $post)
    {
        Gate::authorize('modify', $post);

        $fields = $request ->validate([
            'title' =>['required', 'max:255'],
            'body' =>['required'],
            'image' =>['nullable', 'file', 'max:5000', 'mimes:png,jpg,webp']
        ]);
        
        if ($request->hasFile('image')) {
        if ($post->image) {
            Storage::disk('public')->delete($post->image);
        }
        $fields['image'] = Storage::disk('public')->put('post_images', $request->file('image'));
        }

        
        $post->update($fields);
        return redirect()->route('dashboard')->with('success', 'Post Succesfully Updated');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Post $post)
    {
        Gate::authorize('modify', $post);
        if($post->image){
            Storage::disk('public')->delete('post_images', $post->image);
        }
        $post->delete();
        return back()->with('delete', 'Post Succesfully Deleted');
    }
}
