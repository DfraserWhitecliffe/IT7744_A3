@props(['msg', 'bg'=>'bg-green-500'])
    <p class="text-sm font-meduim text-white px-3 py-1 rounded-md {{$bg}} mb-2">
        {{$msg}}
    </p>