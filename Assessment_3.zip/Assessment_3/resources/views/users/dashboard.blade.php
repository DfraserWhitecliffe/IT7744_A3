<x-layout>
    <h1 class='title text-center'>Hello {{auth()->user()->username}}, you have {{$posts->total()}} posts</h1>
    <div class="card mb-4">
        <h2 class="font-bold mb-4">Create New Post</h2>   
        
        @if (session('success'))
            <x-flashMsg msg="{{session('success')}}" />
        @elseif(session('delete'))
            <x-flashMsg msg="{{session('delete')}}" bg="bg-red-500"/>
        @endif


        <form action="{{route('posts.store')}}" method="post"
        enctype="multipart/form-data">
            @csrf
                <div class="mb-4">
                    <label for="title">Title</label>
                    <input type="text" name="title" class="input
                    @error('title') ring-red-500 @enderror" value="{{old('title')}}">
                    @error('title')
                        <p class="error">{{$message}}</p>
                    @enderror
                </div>
                <div class="mb-4">
                    <label for="body">Content</label>
                    <textarea name="body" class="input
                    @error('body') ring-red-500 @enderror" rows="5">{{old('body')}}</textarea>
                    @error('body')
                        <p class="error">{{$message}}</p>
                    @enderror
                </div>
                <div class="mb-4">
                    <label for="">Image</label>
                    <input type="file" name="image" 
                    class="
                    file:mr-4 
                    file:py-2 
                    file:px-4 
                    file:text-sm 
                    file:font-semibold 
                    file:bg-gray-200 
                    hover:file:bg-blue-100" >
                    @error('image')
                    <p class="error">{{$message}}</p>
                    @enderror
                </div>
                <button class="btn mt-4">Post</button>
        </form>
    </div>

    <h2 class="font-bold mb-4">Your Latest Posts</h2>
    <div class="grid grid-cols-3 gap-6">
        @foreach ($posts as $post)
        <x-postCard :post="$post">
            <a href="{{route('posts.edit', $post)}}" class="bg-green-500 text-white px-2 py-1 text-xs rounded-md">Update</a>
            <form action="{{route('posts.destroy', $post)}}" method="post">
                @csrf
                @method('DELETE')
                <button class="bg-red-500 text-white px-2 py-1 text-xs rounded-md">Delete</button>
            </form>
        </x-postCard>
        @endforeach
    </div>
    <div>{{$posts->links()}}</div>

</x-layout>